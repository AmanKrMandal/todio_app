import React from "react";
import "../../css/home.css";
import fashionIcon from "../../images/fashion_icon.png";
import furnitureIcon from "../../images/furniture_icon.png";
import shoesIcon from "../../images/shoes_icon.png";
import sportsIcon from "../../images/sports_icon.png";
import gameingIcon from "../../images/gameing_icon.png";
import computersIcon from "../../images/computers_icon.png";
import { Link } from "react-router-dom";

const View_Our_Categories = () => {
  return (
    <div className="view_category_section">
      <div className="container">
        <div className="title_section_with_view_all">
          <h2>
            <span>View Our</span> Categories
          </h2>
          <div className="view_all">
            <Link>
              <span>View</span> All +
            </Link>
          </div>
        </div>

        <div className="view_category_list_item">
          <div className="row">
            <div className="col-md-2 view_category_list_item_box_area">
              <div className="view_category_list_item_box">
                <Link>
                  <img src={fashionIcon} />
                  <h3>Fashion</h3>
                </Link>
              </div>
            </div>
            <div className="col-md-2 view_category_list_item_box_area">
              <div className="view_category_list_item_box">
                <Link>
                  <img src={furnitureIcon} />
                  <h3>Furniture</h3>
                </Link>
              </div>
            </div>
            <div className="col-md-2 view_category_list_item_box_area">
              <div className="view_category_list_item_box">
                <Link>
                  <img src={shoesIcon} />
                  <h3>Shoes</h3>
                </Link>
              </div>
            </div>
            <div className="col-md-2 view_category_list_item_box_area">
              <div className="view_category_list_item_box">
                <Link>
                  <img src={sportsIcon} />
                  <h3>Sports</h3>
                </Link>
              </div>
            </div>
            <div className="col-md-2 view_category_list_item_box_area">
              <div className="view_category_list_item_box">
                <Link>
                  <img src={gameingIcon} />
                  <h3>Gameing</h3>
                </Link>
              </div>
            </div>
            <div className="col-md-2 view_category_list_item_box_area">
              <div className="view_category_list_item_box">
                <Link>
                  <img src={computersIcon} />
                  <h3>Computers</h3>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default View_Our_Categories;
