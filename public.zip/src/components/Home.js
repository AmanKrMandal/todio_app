import React, { useRef, useEffect, useState } from "react";

import $ from "jquery";
import { Link } from "react-router-dom";

import Slider from "react-slick";

import bannerImage from "../images/banner.png";
import bdOne from "../images/bd01.png";
import bdTwo from "../images/bd02.png";
import bdThree from "../images/bd03.png";
import bdFour from "../images/bd04.png";
import bdFive from "../images/bd05.png";

import furni01 from "../images/furni01.png";
import furni02 from "../images/furni02.png";
import furni03 from "../images/furni03.png";
import furni04 from "../images/furni04.png";
import furni05 from "../images/furni05.png";
import furni06 from "../images/furni06.png";
import furni07 from "../images/furni07.png";
import furni08 from "../images/furni08.png";

import fashionIcon from "../images/fashion_icon.png";
import furnitureIcon from "../images/furniture_icon.png";
import shoesIcon from "../images/shoes_icon.png";
import sportsIcon from "../images/sports_icon.png";
import gameingIcon from "../images/gameing_icon.png";
import computersIcon from "../images/computers_icon.png";

import kitchenBanner from "../images/kitchen_banner.png";
import kitchen01 from "../images/kitchen01.png";
import kitchen02 from "../images/kitchen02.png";
import kitchen03 from "../images/kitchen03.png";
import kitchen04 from "../images/kitchen04.png";
import kitchen05 from "../images/kitchen05.png";

import popular01 from "../images/popular01.png";
import popular02 from "../images/popular02.png";
import popular03 from "../images/popular03.png";
import popular04 from "../images/popular04.png";
import popular05 from "../images/popular05.png";

import likeProduct01 from "../images/likeProduct01.png";
import likeProduct02 from "../images/likeProduct02.png";
import likeProduct03 from "../images/likeProduct03.png";
import likeProduct04 from "../images/likeProduct04.png";
import likeProduct05 from "../images/likeProduct05.png";

import popularSearchIcon from "../images/popular_search_icon.png";

import livingRoomBanner from "../images/living_room_banner.png";
import living01 from "../images/living01.png";
import living02 from "../images/living02.png";
import living03 from "../images/living03.png";
import living04 from "../images/living04.png";
import living05 from "../images/living05.png";

import bedroomBanner from "../images/bedroom_banner.png";
import bedroom01 from "../images/bedroom01.png";
import bedroom02 from "../images/bedroom02.png";
import bedroom03 from "../images/bedroom03.png";
import bedroom04 from "../images/bedroom04.png";
import bedroom05 from "../images/bedroom05.png";

import bathroom01 from "../images/bathroom01.png";
import bathroom02 from "../images/bathroom02.png";
import bathroom03 from "../images/bathroom03.png";
import bathroom04 from "../images/bathroom04.png";
import bathroom05 from "../images/bathroom05.png";

import gardenBanner from "../images/garden_banner.png";
import garden01 from "../images/garden01.png";
import garden02 from "../images/garden02.png";
import garden03 from "../images/garden03.png";
import garden04 from "../images/garden04.png";
import garden05 from "../images/garden05.png";

import recommend01 from "../images/recommend01.png";
import recommend02 from "../images/recommend02.png";
import recommend03 from "../images/recommend03.png";
import recommend04 from "../images/recommend04.png";
import recommend05 from "../images/recommend05.png";
import recommend06 from "../images/recommend06.png";
import recommend07 from "../images/recommend07.png";
import recommend08 from "../images/recommend08.png";
import recommend09 from "../images/recommend09.png";

import blog01 from "../images/blog01.png";
import blog02 from "../images/blog02.png";
import blog03 from "../images/blog03.png";
import blog04 from "../images/blog04.png";

import "../css/home.css";

const Home = () => {
  var settings = {
    dots: false,
    arrows: true,
    infinite: true,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 400,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 760,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
    ],
  };

  var settingsSmallSlider = {
    dots: false,
    arrows: true,
    infinite: true,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
  };

  var settingsPopularSearchSlider = {
    dots: false,
    arrows: true,
    infinite: true,
    speed: 500,
    slidesToShow: 6,
    slidesToScroll: 1,
  };

  return (
    <div className="home_container">
      <div className="banner_section">
        <img src={bannerImage} />
        <div className="banner_content">
          <h1>Online furniture search engine</h1>
          <span>100+ eshops under one roof </span>
          <p>Furnish your home quickly and easily</p>
        </div>
      </div>

      <div className="best_deals_section">
        <div className="container">
          <div className="best_deals_area">
            <div className="title_section_with_view_all">
              <h2>
                <span>Todays</span> Best Deals
              </h2>
              <div className="view_all">
                <Link>
                  <span>View</span> All +
                </Link>
              </div>
            </div>
            <div className="best_deals_product_list">
              <Slider {...settings}>
                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdOne} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Bedroom</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">$ 29.99</div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdTwo} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Furniture</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">
                      <span>$ 59.99</span> $ 39.99
                    </div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdThree} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Lamp</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">$ 29.99</div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdFour} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Furniture</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">$ 29.99</div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdFive} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Decoration</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">
                      <span>$ 29.99</span> $ 19.99
                    </div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdOne} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Bedroom</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">$ 29.99</div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdTwo} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Furniture</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">
                      <span>$ 59.99</span> $ 39.99
                    </div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdThree} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Lamp</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">$ 29.99</div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdFour} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Furniture</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">$ 29.99</div>
                  </div>
                </div>

                <div className="best_deals_product_list_box">
                  <div className="best_deals_product_list_box_img">
                    <img src={bdFive} />
                  </div>
                  <div className="best_deals_product_list_box_cont">
                    <span>Decoration</span>
                    <h3>Jean Lion king black</h3>
                    <p>
                      Ut repellat sint et enim quis ut mollitia repudiandae.
                    </p>
                    <div className="price_box">
                      <span>$ 29.99</span> $ 19.99
                    </div>
                  </div>
                </div>
              </Slider>
            </div>
          </div>
        </div>
      </div>

      <div className="find_furniture_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>Find Furniture</span> For your Rooms
            </h2>
          </div>

          <div className="find_furniture_area">
            <div className="row">
              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni01} />
                  <h3>Livivng Room</h3>

                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Livivng Room</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni02} />
                  <h3>Bedroom</h3>
                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Bedroom</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni03} />
                  <h3>Kitchen</h3>
                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Kitchen</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni04} />
                  <h3>Bathroom</h3>
                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Bathroom</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni05} />
                  <h3>Office</h3>
                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Office</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni06} />
                  <h3>Hall</h3>
                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Hall</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni07} />
                  <h3>Garden</h3>
                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Garden</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="find_furniture_area_box">
                  <img src={furni08} />
                  <h3>Kids Room</h3>
                  <div className="flip-card">
                    <div className="flip-card-inner">
                      <div className="flip-card-back">
                        <div className="furniture_view">
                          <h4>Kids Room</h4>
                          <Link>
                            <span>View</span> This +
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="view_category_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>View Our</span> Categories
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>

          <div className="view_category_list_item">
            <div className="row">
              <div className="col-md-2 view_category_list_item_box_area">
                <div className="view_category_list_item_box">
                  <Link>
                    <img src={fashionIcon} />
                    <h3>Fashion</h3>
                  </Link>
                </div>
              </div>
              <div className="col-md-2 view_category_list_item_box_area">
                <div className="view_category_list_item_box">
                  <Link>
                    <img src={furnitureIcon} />
                    <h3>Furniture</h3>
                  </Link>
                </div>
              </div>
              <div className="col-md-2 view_category_list_item_box_area">
                <div className="view_category_list_item_box">
                  <Link>
                    <img src={shoesIcon} />
                    <h3>Shoes</h3>
                  </Link>
                </div>
              </div>
              <div className="col-md-2 view_category_list_item_box_area">
                <div className="view_category_list_item_box">
                  <Link>
                    <img src={sportsIcon} />
                    <h3>Sports</h3>
                  </Link>
                </div>
              </div>
              <div className="col-md-2 view_category_list_item_box_area">
                <div className="view_category_list_item_box">
                  <Link>
                    <img src={gameingIcon} />
                    <h3>Gameing</h3>
                  </Link>
                </div>
              </div>
              <div className="col-md-2 view_category_list_item_box_area">
                <div className="view_category_list_item_box">
                  <Link>
                    <img src={computersIcon} />
                    <h3>Computers</h3>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="finding_kitchen_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>tending Items For</span> kitchen
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All + <span>(584 products)</span>
              </Link>
            </div>
          </div>
          <div className="section_banner_area">
            <img src={kitchenBanner} />
            <div className="section_banner_cont">
              <h3>Kitchen</h3>
            </div>
          </div>
          <div className="small_product_slider">
            <Slider {...settingsSmallSlider}>
              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={kitchen01} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={kitchen02} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={kitchen03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={kitchen04} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={kitchen05} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={kitchen01} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="popular_product_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>popular</span> Products
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>
          <div className="best_deals_product_list">
            <Slider {...settings}>
              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular01} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular02} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>kitchen</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular03} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Living Room</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular04} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Hall</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular05} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Accessories</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdOne} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Bedroom</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdTwo} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdThree} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFour} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFive} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Decoration</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="popular_search_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>popular </span>Searches
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>

          <div className="popular_search_area">
            <Slider {...settingsPopularSearchSlider}>
              <div className="popular_search_box">
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
              </div>
              <div className="popular_search_box">
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
              </div>
              <div className="popular_search_box">
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
              </div>
              <div className="popular_search_box">
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
              </div>
              <div className="popular_search_box">
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
              </div>
              <div className="popular_search_box">
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
              </div>
              <div className="popular_search_box">
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
                <div className="popular_search_box_area">
                  <img src={popularSearchIcon} />
                  <h3>Sven Tonal Weave Reversible Corner</h3>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="your_recent_views_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>Things</span> You Could Like
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>
          <div className="best_deals_product_list">
            <Slider {...settings}>
              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular01} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular02} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>kitchen</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular03} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Living Room</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular04} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Hall</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={popular05} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Accessories</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdOne} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Bedroom</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdTwo} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdThree} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFour} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFive} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Decoration</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="think_you_like_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>Things</span> You Could Like
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>
          <div className="best_deals_product_list">
            <Slider {...settings}>
              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct01} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct02} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>kitchen</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct03} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Living Room</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct04} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Hall</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct05} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Accessories</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdOne} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Bedroom</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdTwo} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdThree} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFour} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFive} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Decoration</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="living_room_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>tending Items For</span> Living Room
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All + <span>(584 products)</span>
              </Link>
            </div>
          </div>
          <div className="section_banner_area">
            <img src={livingRoomBanner} />
            <div className="section_banner_cont">
              <h3>Living Room</h3>
            </div>
          </div>
          <div className="small_product_slider">
            <Slider {...settingsSmallSlider}>
              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={living01} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={living02} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={living03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={living04} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={living05} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={living03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="bedroom_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>tending Items For</span> BEDROOM
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All + <span>(584 products)</span>
              </Link>
            </div>
          </div>
          <div className="section_banner_area">
            <img src={bedroomBanner} />
            <div className="section_banner_cont">
              <h3>Bedroom</h3>
            </div>
          </div>
          <div className="small_product_slider">
            <Slider {...settingsSmallSlider}>
              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bedroom01} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bedroom02} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bedroom03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bedroom04} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bedroom05} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bedroom03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="think_you_like_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>Things</span> You Could Like
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>
          <div className="best_deals_product_list">
            <Slider {...settings}>
              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct01} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct02} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>kitchen</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct03} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Living Room</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct04} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Hall</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct05} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Accessories</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdOne} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Bedroom</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdTwo} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdThree} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFour} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFive} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Decoration</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="bedroom_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>tending Items For</span> BATHROOM
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All + <span>(584 products)</span>
              </Link>
            </div>
          </div>
          <div className="section_banner_area">
            <img src={bedroomBanner} />
            <div className="section_banner_cont">
              <h3>Bathroom</h3>
            </div>
          </div>
          <div className="small_product_slider">
            <Slider {...settingsSmallSlider}>
              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bathroom01} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bathroom02} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bathroom03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bathroom04} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bathroom05} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={bathroom03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="recent_product_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>Recent</span> Products
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>
          <div className="best_deals_product_list">
            <Slider {...settings}>
              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct01} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct02} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>kitchen</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct03} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Living Room</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct04} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Hall</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={likeProduct05} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Accessories</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdOne} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Bedroom</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdTwo} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 59.99</span> $ 39.99
                  </div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdThree} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Lamp</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFour} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Furniture</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">$ 29.99</div>
                </div>
              </div>

              <div className="best_deals_product_list_box">
                <div className="best_deals_product_list_box_img">
                  <img src={bdFive} />
                </div>
                <div className="best_deals_product_list_box_cont">
                  <span>Decoration</span>
                  <h3>Jean Lion king black</h3>
                  <p>Ut repellat sint et enim quis ut mollitia repudiandae.</p>
                  <div className="price_box">
                    <span>$ 29.99</span> $ 19.99
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="garden_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>tending Items For</span> GARDEN
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All + <span>(584 products)</span>
              </Link>
            </div>
          </div>
          <div className="section_banner_area">
            <img src={gardenBanner} />
            <div className="section_banner_cont">
              <h3>Garden</h3>
            </div>
          </div>
          <div className="small_product_slider">
            <Slider {...settingsSmallSlider}>
              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={garden01} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={garden02} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={garden03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={garden04} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={garden05} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>

              <div className="small_product_slider_list_box">
                <div className="small_product_slider_sec">
                  <div className="small_product_slider_list_box_img">
                    <img src={garden03} />
                  </div>
                  <div className="small_product_slider_list_box_cont">
                    <h3>Jean Lion king black</h3>
                  </div>
                </div>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      <div className="we_recommend_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>E-shops</span> we recommend
            </h2>
          </div>
          <div className="recommend_area">
            <div className="recommend_box">
              <img src={recommend01} />
            </div>
            <div className="recommend_box">
              <img src={recommend02} />
            </div>
            <div className="recommend_box">
              <img src={recommend03} />
            </div>
            <div className="recommend_box">
              <img src={recommend04} />
            </div>
            <div className="recommend_box">
              <img src={recommend05} />
            </div>
            <div className="recommend_box">
              <img src={recommend04} />
            </div>
            <div className="recommend_box">
              <img src={recommend06} />
            </div>
            <div className="recommend_box">
              <img src={recommend07} />
            </div>
            <div className="recommend_box">
              <img src={recommend08} />
            </div>
            <div className="recommend_box">
              <img src={recommend09} />
            </div>
          </div>
        </div>
      </div>

      <div className="blog_section">
        <div className="container">
          <div className="title_section_with_view_all">
            <h2>
              <span>From our</span> BLOG
            </h2>
            <div className="view_all">
              <Link>
                <span>View</span> All +
              </Link>
            </div>
          </div>
          <div className="blog_area">
            <div className="row">
              <div className="col-md-3">
                <div className="blog_box">
                  <div className="blog_box_img">
                    <img src={blog01} />
                  </div>
                  <div className="blog_box_cont">
                    <div className="auther_date_box">
                      <p className="auther_name">By John Doe</p>
                      <p className="post_date">
                        <i className="fa fa-calendar-o" aria-hidden="true"></i>{" "}
                        03.05.2023
                      </p>
                    </div>
                    <p className="shot_text">
                      Lorem Ipsum is simply dummy text of the printing
                      typesetting...
                    </p>
                    <Link to="/">Read More</Link>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="blog_box">
                  <div className="blog_box_img">
                    <img src={blog02} />
                  </div>
                  <div className="blog_box_cont">
                    <div className="auther_date_box">
                      <p className="auther_name">By John Doe</p>
                      <p className="post_date">
                        <i className="fa fa-calendar-o" aria-hidden="true"></i>{" "}
                        03.05.2023
                      </p>
                    </div>
                    <p className="shot_text">
                      Lorem Ipsum is simply dummy text of the printing
                      typesetting...
                    </p>
                    <Link to="/">Read More</Link>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="blog_box">
                  <div className="blog_box_img">
                    <img src={blog03} />
                  </div>
                  <div className="blog_box_cont">
                    <div className="auther_date_box">
                      <p className="auther_name">By John Doe</p>
                      <p className="post_date">
                        <i className="fa fa-calendar-o" aria-hidden="true"></i>{" "}
                        03.05.2023
                      </p>
                    </div>
                    <p className="shot_text">
                      Lorem Ipsum is simply dummy text of the printing
                      typesetting...
                    </p>
                    <Link to="/">Read More</Link>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="blog_box">
                  <div className="blog_box_img">
                    <img src={blog04} />
                  </div>
                  <div className="blog_box_cont">
                    <div className="auther_date_box">
                      <p className="auther_name">By John Doe</p>
                      <p className="post_date">
                        <i className="fa fa-calendar-o" aria-hidden="true"></i>{" "}
                        03.05.2023
                      </p>
                    </div>
                    <p className="shot_text">
                      Lorem Ipsum is simply dummy text of the printing
                      typesetting...
                    </p>
                    <Link to="/">Read More</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

$(document).ready(function () {
  /* ========== Fixed Header ========== */
  // $(window)
  //   .scroll(function () {
  //     //var scroll = $(window).scrollTop();
  //     if ($(window).scrollTop() >= 1) {
  //       $(".header_wrapper").addClass("fixed");
  //     } else {
  //       $(".header_wrapper").removeClass("fixed");
  //     }
  //   })
  //   .scroll();
  /* ========== End Fixed Header ========== */

  // Mobile Menu start

  function sidemenu() {
    $(".nav_sec").toggleClass("slidein");
    $(".nav_sec").prepend('<div class="cls-btn"></div>');

    $(".cls-btn").on("click", function () {
      $(".nav_sec").removeClass("slidein");
    });
  }

  $(".toggle-menu").click(sidemenu);
  $(".nav_sec ul > li > ul").parent().prepend('<i class="arw-nav"></i>');

  function subMenu() {
    $(this).parent("li").find("> ul").stop(true, true).slideToggle();
    $(this).parents("li").siblings().find("ul").stop(true, true).slideUp();
    $(this).toggleClass("actv");
    $(this).parent().siblings().find(".arw-nav").removeClass("actv");
  }
  $(".nav_sec ul > li > .arw-nav").on("click", subMenu);

  // Mobile Menu ends
});

export default Home;
