import React, { useRef, useEffect, useState } from "react";

import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";

import $ from "jquery";
import { Link } from "react-router-dom";

import Slider from "react-slick";

import aboutBanner from "../images/about_banner.png";
import lop01 from "../images/lop01.png";
import lop02 from "../images/lop02.png";
import lop03 from "../images/lop03.png";
import lop04 from "../images/lop04.png";
import lop05 from "../images/lop05.png";
import lop06 from "../images/lop06.png";

import "../css/about.css";

const Home = () => {
  return (
    <div className="about_container">
      <div className="banner_section inner_banner">
        <img src={aboutBanner} />
        <div className="banner_content">
          <h1>About US</h1>
          <div className="breadcrumbs_section">
            <ul>
              <li>
                <Link to="/">
                  Todio.it
                  <i className="fa fa-angle-right" aria-hidden="true"></i>
                </Link>
              </li>
              <li>About Us</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="about_wrapper_area">
        <div className="container">
          <div className="about_content_area">
            <Tabs>
              <div className="tab_box">
                <TabList>
                  <Tab>About Todio.it</Tab>
                  <Tab>With Us</Tab>
                  <Tab>Vacancies</Tab>
                  <Tab>For the Media</Tab>
                  <Tab>For Partners</Tab>
                  <Tab>Contact</Tab>
                </TabList>
              </div>

              <div className="tab_content_box_wrap">
                <TabPanel>
                  <div className="tab_content_box">
                    <h2>
                      <span>About</span> todio.it
                    </h2>
                    <p>
                      Contrary to popular belief, Lorem Ipsum is not simply
                      random text. It has roots in a piece of classical Latin
                      literature from 45 BC, making it over 2000 years old.
                      Richard McClintock, a Latin professor at Hampden-Sydney
                      College in Virginia, looked up one of the more obscure
                      Latin words, consectetur, from a Lorem Ipsum passage, and
                      going through the cites of the word in classical
                      literature, discovered the undoubtable source. Lorem Ipsum
                      comes from sections 1.10.32 and 1.10.33 of "de Finibus
                      Bonorum et Malorum" (The Extremes of Good and Evil) by
                      Cicero, written in 45 BC. This book is a treatise on the
                      theory of ethics, very popular during the Renaissance. The
                      first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..",
                      comes from a line in section 1.10.32.
                    </p>
                    <p>
                      The standard chunk of Lorem Ipsum used since the 1500s is
                      reproduced below for those interested. Sections 1.10.32
                      and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero
                      are also reproduced in their exact original form,
                      accompanied by English versions from the 1914 translation
                      by H. Rackham.
                    </p>
                    <h3>
                      List your products on TODIO and effectively reach a high
                      volume of customers
                    </h3>
                    <div className="list_of_product_section">
                      <div className="row">
                        <div className="col-md-4">
                          <div className="list_of_product_box">
                            <div className="list_of_product_box_img">
                              <img src={lop01} />
                            </div>
                            <p>
                              Simple and easy way to target people interested in
                              buying Products
                            </p>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="list_of_product_box">
                            <div className="list_of_product_box_img">
                              <img src={lop02} />
                            </div>
                            <p>10 million monthly users and 2300 clients</p>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="list_of_product_box">
                            <div className="list_of_product_box_img">
                              <img src={lop03} />
                            </div>
                            <p>
                              Easy campaign management, at no additional costs
                            </p>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="list_of_product_box">
                            <div className="list_of_product_box_img">
                              <img src={lop04} />
                            </div>
                            <p>
                              Increase in traffic, sales and brand awareness
                            </p>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="list_of_product_box">
                            <div className="list_of_product_box_img">
                              <img src={lop05} />
                            </div>
                            <p>
                              Affordable, you only pay for customers who visit
                              your site by the CPC model
                            </p>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="list_of_product_box">
                            <div className="list_of_product_box_img">
                              <img src={lop06} />
                            </div>
                            <p>
                              Precise loading and sorting of products from the
                              XML feed
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <h2>
                      <span>todio.it</span> story
                    </h2>
                    <p>
                      Contrary to popular belief, Lorem Ipsum is not simply
                      random text. It has roots in a piece of classical Latin
                      literature from 45 BC, making it over 2000 years old.
                      Richard McClintock, a Latin professor at Hampden-Sydney
                      College in Virginia, looked up one of the more obscure
                      Latin words, consectetur, from a Lorem Ipsum passage, and
                      going through the cites of the word in classical
                      literature, discovered the undoubtable source. Lorem Ipsum
                      comes from sections 1.10.32 and 1.10.33 of "de Finibus
                      Bonorum et Malorum" (The Extremes of Good and Evil) by
                      Cicero, written in 45 BC. This book is a treatise on the
                      theory of ethics, very popular during the Renaissance. The
                      first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..",
                      comes from a line in section 1.10.32.
                    </p>
                    <p>
                      The standard chunk of Lorem Ipsum used since the 1500s is
                      reproduced below for those interested. Sections 1.10.32
                      and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero
                      are also reproduced in their exact original form,
                      accompanied by English versions from the 1914 translation
                      by H. Rackham.
                    </p>
                  </div>
                </TabPanel>
                <TabPanel>
                  <h2>Content Coming Soon.</h2>
                </TabPanel>
                <TabPanel>
                  <h2>Content Coming Soon.</h2>
                </TabPanel>
                <TabPanel>
                  <h2>Content Coming Soon.</h2>
                </TabPanel>
                <TabPanel>
                  <h2>Content Coming Soon.</h2>
                </TabPanel>
                <TabPanel>
                  <h2>Content Coming Soon.</h2>
                </TabPanel>
              </div>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

$(document).ready(function () {
  /* ========== Fixed Header ========== */
  // $(window)
  //   .scroll(function () {
  //     //var scroll = $(window).scrollTop();
  //     if ($(window).scrollTop() >= 1) {
  //       $(".header_wrapper").addClass("fixed");
  //     } else {
  //       $(".header_wrapper").removeClass("fixed");
  //     }
  //   })
  //   .scroll();
  /* ========== End Fixed Header ========== */

  // Mobile Menu start

  function sidemenu() {
    $(".nav_sec").toggleClass("slidein");
    $(".nav_sec").prepend('<div class="cls-btn"></div>');

    $(".cls-btn").on("click", function () {
      $(".nav_sec").removeClass("slidein");
    });
  }

  $(".toggle-menu").click(sidemenu);
  $(".nav_sec ul > li > ul").parent().prepend('<i class="arw-nav"></i>');

  function subMenu() {
    $(this).parent("li").find("> ul").stop(true, true).slideToggle();
    $(this).parents("li").siblings().find("ul").stop(true, true).slideUp();
    $(this).toggleClass("actv");
    $(this).parent().siblings().find(".arw-nav").removeClass("actv");
  }
  $(".nav_sec ul > li > .arw-nav").on("click", subMenu);

  // Mobile Menu ends
});

export default Home;
