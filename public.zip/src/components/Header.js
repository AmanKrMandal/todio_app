import React, { useRef, useEffect, useState } from "react";

import { Link } from "react-router-dom";
import { NavLink } from "react-router-dom";

import menuIcon from "../images/menu-icon.png";
import logo from "../images/logo.png";

const Header = () => {
  return (
    <div className="header_wrapper">
      <div className="header_top">
        <div className="container">
          <div className="row">
            <div className="col-md-2 logo_wrap">
              <div className="logo_area">
                <a href="/">
                  <img src={logo} />
                </a>
              </div>
            </div>
            <div className="col-md-8">
              <div className="search_area">
                <form>
                  <input type="text" placeholder="Search product..." />
                  <input type="submit" />
                </form>
              </div>
            </div>
            <div className="col-md-2">
              <div className="top_cart_area">
                <ul>
                  <li>
                    <span className="cart_number">3</span>
                    <Link to="about">
                      <svg
                        width="29"
                        height="24"
                        viewBox="0 0 29 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M21.048 0C17.7736 0 15.9961 1.19156 14.5 2.7231C13.003 1.19092 11.2256 0 7.95194 0C3.27458 0 0 2.97885 0 7.31899C0 9.87234 1.30978 12.5107 3.74211 14.7235L13.1902 23.4891C13.5647 23.8297 14.0323 24 14.5 24C14.9677 24 15.4353 23.8297 15.8098 23.4891L25.2579 14.7235C27.6902 12.5107 29 9.9573 29 7.31899C29 3.06381 25.7256 0 21.048 0ZM22.639 12.3402L14.4999 19.8295L6.36076 12.2547C4.67656 10.7225 3.74124 8.93586 3.74124 7.31882C3.74124 4.85095 5.33146 3.40418 7.95107 3.40418C10.2895 3.40418 11.0383 4.17027 12.8158 6.04249L13.1902 6.38313C13.9383 7.14922 15.342 7.14922 15.9969 6.38313L16.3713 6.04249C18.1488 4.17039 18.8037 3.40418 21.236 3.40418C23.8556 3.40418 25.4459 4.85086 25.4459 7.31882C25.2579 9.02132 24.3224 10.7232 22.639 12.3402Z"
                          fill="white"
                        />
                      </svg>
                    </Link>
                  </li>
                  <li>
                    <Link to="/product">
                      <svg
                        width="29"
                        height="29"
                        viewBox="0 0 29 29"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M14.4725 0C18.9249 0 22.5407 3.61582 22.5407 8.06819C22.5407 12.5206 18.9249 16.1364 14.4725 16.1364C10.0202 16.1364 6.40436 12.5206 6.40436 8.06819C6.40436 3.61582 10.0202 0 14.4725 0ZM14.4725 2.01705C11.1323 2.01705 8.42141 4.7279 8.42141 8.06819C8.42141 11.4085 11.1323 14.1193 14.4725 14.1193C17.8128 14.1193 20.5237 11.4085 20.5237 8.06819C20.5237 4.7279 17.8128 2.01705 14.4725 2.01705Z"
                          fill="white"
                        />
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M2.7065 27.9025C2.7065 28.4592 2.25469 28.911 1.69798 28.911C1.14126 28.911 0.689453 28.4592 0.689453 27.9025C0.689453 20.2953 6.86565 14.1191 14.4728 14.1191C22.08 14.1191 28.2561 20.2953 28.2561 27.9025C28.2561 28.4592 27.8043 28.911 27.2476 28.911C26.6909 28.911 26.2391 28.4592 26.2391 27.9025C26.2391 21.4088 20.9667 16.1362 14.4728 16.1362C7.97906 16.1362 2.7065 21.4086 2.7065 27.9025Z"
                          fill="white"
                        />
                      </svg>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="header_bottom">
        <div className="container">
          <div className="main_menu col-md-12">
            <span className="toggle-menu">
              <img src={menuIcon} />
            </span>
            <nav className="nav_sec">
              <ul>
                <li>
                  <NavLink to="/">
                    Furniture{" "}
                    <i class="fa fa-chevron-down" aria-hidden="true"></i>
                  </NavLink>
                  <ul>
                    <li>
                      <NavLink to="/">Furniture 01</NavLink>
                    </li>
                    <li>
                      <NavLink to="/">Furniture 02</NavLink>
                    </li>
                  </ul>
                </li>
                <li>
                  <NavLink to="/">
                    Decoraton{" "}
                    <i class="fa fa-chevron-down" aria-hidden="true"></i>
                  </NavLink>
                  <ul>
                    <li>
                      <NavLink to="/">Decoraton 01</NavLink>
                    </li>
                    <li>
                      <NavLink to="/">Decoraton 02</NavLink>
                    </li>
                  </ul>
                </li>
                <li>
                  <NavLink to="/">
                    Textile{" "}
                    <i class="fa fa-chevron-down" aria-hidden="true"></i>
                  </NavLink>
                  <ul>
                    <li>
                      <NavLink to="/">Textile 01</NavLink>
                    </li>
                    <li>
                      <NavLink to="/">Textile 02</NavLink>
                    </li>
                  </ul>
                </li>
                <li>
                  <NavLink to="/">
                    Lamps <i class="fa fa-chevron-down" aria-hidden="true"></i>
                  </NavLink>
                  <ul>
                    <li>
                      <NavLink to="/">Lamps 01</NavLink>
                    </li>
                    <li>
                      <NavLink to="/">Lamps 02</NavLink>
                    </li>
                  </ul>
                </li>
                <li>
                  <NavLink to="/">
                    Construction{" "}
                    <i class="fa fa-chevron-down" aria-hidden="true"></i>
                  </NavLink>
                  <ul>
                    <li>
                      <NavLink to="/">Construction 01</NavLink>
                    </li>
                    <li>
                      <NavLink to="/">Construction 02</NavLink>
                    </li>
                  </ul>
                </li>
                <li>
                  <NavLink to="/">
                    DISCOUNTS{" "}
                    <i class="fa fa-chevron-down" aria-hidden="true"></i>
                  </NavLink>
                  <ul>
                    <li>
                      <NavLink to="/">Discounts 01</NavLink>
                    </li>
                    <li>
                      <NavLink to="/">Discounts 02</NavLink>
                    </li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
