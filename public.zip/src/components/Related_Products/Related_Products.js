import React from "react";
import { TabPanel, Tabs } from "react-tabs";

import cat_product_item01 from "../../images/cat_product_item01.png";
import cat_product_item02 from "../../images/cat_product_item02.png";
import cat_product_item03 from "../../images/cat_product_item03.png";
import cat_product_item04 from "../../images/cat_product_item04.png";
import cat_product_item05 from "../../images/cat_product_item05.png";
import cat_product_item06 from "../../images/cat_product_item06.png";
import cat_product_item07 from "../../images/cat_product_item07.png";
import available_icon from "../../images/available_icon.png";
import free_icon from "../../images/free_icon.png";

const Related_Products = () => {
  return (
    <div>
      <Tabs>
        <div className="category_product_list_wrap">
          <TabPanel>
            <div className="category_product_list_area">
              <div className="row">
                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item01} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item02} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item03} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item04} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item05} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item06} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item07} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="category_product_list_box">
                    <div className="discount_wish_area">
                      <div className="category_product_discount">
                        <p>-25%</p>
                      </div>
                      <div className="category_product_wish">
                        <a href="#">
                          <i className="fa fa-heart-o" aria-hidden="true"></i>
                        </a>
                        <p>4</p>
                      </div>
                    </div>
                    <div className="category_product_list_box_img">
                      <img src={cat_product_item01} />
                    </div>
                    <div className="category_product_list_box_cont">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                    </div>

                    <div className="category_product_list_box_cont_full">
                      <ul>
                        <li>
                          <img src={available_icon} /> Available
                        </li>
                        <li>
                          <img src={free_icon} /> Free
                        </li>
                      </ul>
                      <h3>Sofa In Orange Colour asd dssdfsdfsdfsd sd as</h3>
                      <div className="category_cont">
                        <p>
                          Upholstered in a soft and hard hello how wearing jumbo
                          cord fabric ..
                        </p>
                      </div>
                      <div className="cat_product_price">
                        <p>
                          $ 39.99 <span>$ 59.99</span>
                        </p>
                      </div>
                      <div className="cat_buttons">
                        <a className="go_details" href="#">
                          Details
                        </a>
                        <a className="go_shop" href="#">
                          Go to shop{" "}
                          <i className="fa fa-angle-right" aria-hidden="true"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabPanel>
        </div>
      </Tabs>
    </div>
  );
};

export default Related_Products;
