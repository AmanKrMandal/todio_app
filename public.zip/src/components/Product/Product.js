import React, { useState } from "react";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import { Link } from "react-router-dom";

import Slider from "react-slick";
import Range from "@mui/material/Slider";
import { BiChevronRight } from "react-icons/bi";

import Available from "../../images/Product_Image/Available.png";
import delivery from "../../images/Product_Image/delivery.png";
import search_add from "../../images/Product_Image/search_add.png";

import fashionIcon from "../../images/fashion_icon.png";
import furnitureIcon from "../../images/furniture_icon.png";
import shoesIcon from "../../images/shoes_icon.png";
import sportsIcon from "../../images/sports_icon.png";
import gameingIcon from "../../images/gameing_icon.png";
import computersIcon from "../../images/computers_icon.png";

import cat_product_item01 from "../../images/cat_product_item01.png";
import cat_product_item02 from "../../images/cat_product_item02.png";
import cat_product_item03 from "../../images/cat_product_item03.png";
import cat_product_item04 from "../../images/cat_product_item04.png";
import cat_product_item05 from "../../images/cat_product_item05.png";
import cat_product_item06 from "../../images/cat_product_item06.png";
import cat_product_item07 from "../../images/cat_product_item07.png";
import available_icon from "../../images/available_icon.png";
import free_icon from "../../images/free_icon.png";

import Similar_Categories01 from "../../images/Product_Image/Similar_Categories01.png";
import Similar_Categories02 from "../../images/Product_Image/Similar_Categories02.png";
import Similar_Categories03 from "../../images/Product_Image/Similar_Categories03.png";
import Similar_Categories04 from "../../images/Product_Image/Similar_Categories04.png";
import Similar_Categories05 from "../../images/Product_Image/Similar_Categories05.png";

import shoplist from "../../images/Product_Image/shoplist.png";
import shoplist01 from "../../images/Product_Image/shoplist01.png";
import shoplist02 from "../../images/Product_Image/shoplist02.png";
import shoplist03 from "../../images/Product_Image/shoplist03.png";
import shoplist04 from "../../images/Product_Image/shoplist04.png";
import "./Product.css";
import "../../css/category.css";
import $ from "jquery";

$(".img_producto_container")
  // tile mouse actions
  .on("mouseover", function () {
    $(this)
      .children(".img_producto")
      .css({ transform: "scale(" + $(this).attr("data-scale") + ")" });
  })
  .on("mouseout", function () {
    $(this).children(".img_producto").css({ transform: "scale(1)" });
  })
  .on("mousemove", function (e) {
    $(this)
      .children(".img_producto")
      .css({
        "transform-origin":
          ((e.pageX - $(this).offset().left) / $(this).width()) * 100 +
          "% " +
          ((e.pageY - $(this).offset().top) / $(this).height()) * 100 +
          "%",
      });
  });

function Product() {
  const [nav1, setNav1] = useState();
  const [nav2, setNav2] = useState();
  let product_list_slider = {
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
  };
  var settingsSmallSlider = {
    dots: false,
    arrows: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
  };
  var SimilarCategoriesSlider = {
    dots: false,
    arrows: true,
    infinite: true,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
  };

  const [range, setRange] = React.useState([0, 100]);
  function handleChanges(event, newValue) {
    setRange(newValue);
  }
  return (
    <main className="product_container">
      <div className="container">
        <div className="row">
          <div className="col-md-3">
            <div className="category_left_section">
              <div className="remove_filters_section">
                <h3>Remove filters</h3>
                <ul>
                  <li>
                    <div className="remove_filters_box">
                      <p>without shade</p>
                      <span>
                        <a href="#">
                          <i className="fa fa-times" aria-hidden="true"></i>
                        </a>
                      </span>
                    </div>
                  </li>
                  <li>
                    <div className="remove_filters_box">
                      <p>modern</p>
                      <span>
                        <a href="#">
                          <i className="fa fa-times" aria-hidden="true"></i>
                        </a>
                      </span>
                    </div>
                  </li>
                  <li>
                    <a href="#">Remove everything</a>
                  </li>
                </ul>
              </div>

              <div className="Search_in_the_category_section">
                <h3>Search in the category</h3>
                <form>
                  <input type="text" />
                  <input type="submit" />
                </form>
              </div>

              <div className="category_item_list">
                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="multi_place" />
                      <label className="check_available" htmlFor="multi_place">
                        <img src={available_icon} /> Available
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="two_digit" />
                      <label htmlFor="two_digit">
                        <img src={free_icon} /> Free
                      </label>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Price</h4>

                <div className="price_range_section">
                  <div className="price_range_section_box">
                    <div>$ {range[0]}</div>
                    <div>$ {range[1]}</div>
                  </div>
                  <Range
                    value={range}
                    onChange={handleChanges}
                    valueLabelDisplay="auto"
                  />
                </div>

                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="cheap" />
                      <label htmlFor="cheap">Cheap</label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="luxurious" />
                      <label htmlFor="luxurious">Luxurious</label>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Categories</h4>

                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="furniture" />
                      <label htmlFor="furniture">Furniture</label>
                      <span>84</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="decoraton" />
                      <label htmlFor="decoraton">Decoraton</label>
                      <span>259</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="iextile" />
                      <label htmlFor="iextile">Textile</label>
                      <span>8</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="lamps" />
                      <label htmlFor="lamps">Lamps</label>
                      <span>45</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="construction" />
                      <label htmlFor="construction">Construction</label>
                      <span>36</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="accessories" />
                      <label htmlFor="accessories">Accessories</label>
                      <span>56</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="others" />
                      <label htmlFor="others">Others</label>
                      <span>5</span>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Subcategories</h4>

                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="sofas" />
                      <label htmlFor="sofas">Sofas</label>
                      <span>84</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="sofa" />
                      <label htmlFor="sofa">Sofa</label>
                      <span>259</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="armchairs_seats" />
                      <label htmlFor="armchairs_seats">
                        Armchairs and Seats
                      </label>
                      <span>8</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="beds" />
                      <label htmlFor="beds">Beds</label>
                      <span>45</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="cabinets_lockers" />
                      <label htmlFor="cabinets_lockers">
                        Cabinets and lockers
                      </label>
                      <span>36</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="fitted_kitchens" />
                      <label htmlFor="fitted_kitchens">Fitted kitchens</label>
                      <span>56</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="coffee_tables" />
                      <label htmlFor="coffee_tables">
                        Tables and Coffee tables
                      </label>
                      <span>5</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="sittings" />
                      <label htmlFor="sittings">Sittings</label>
                      <span>5</span>
                    </div>

                    <div className="form-group">
                      <input type="checkbox" id="furniture_set" />
                      <label htmlFor="furniture_set">Furniture set</label>
                      <span>5</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="storage_spaces" />
                      <label htmlFor="storage_spaces">Storage spaces</label>
                      <span>5</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="office_furnishings" />
                      <label htmlFor="office_furnishings">
                        Office furnishings
                      </label>
                      <span>5</span>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Brand</h4>

                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="febonic" />
                      <label htmlFor="febonic">Febonic</label>
                      <span>84</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="durian" />
                      <label htmlFor="durian">Durian</label>
                      <span>259</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="dreamzz_furniture" />
                      <label htmlFor="dreamzz_furniture">
                        Dreamzz Furniture
                      </label>
                      <span>8</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="adorn_homez" />
                      <label htmlFor="adorn_homez">Adorn Homez</label>
                      <span>45</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="furnitech" />
                      <label htmlFor="furnitech">Furnitech</label>
                      <span>36</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="wakefit" />
                      <label htmlFor="wakefit">Wakefit</label>
                      <span>56</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="others" />
                      <label htmlFor="others">Others</label>
                      <span>5</span>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Color</h4>

                <div className="checkbox_section for_color">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="red_color" />
                      <label className="red_color" htmlFor="red_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="yellow_color" />
                      <label className="yellow_color" htmlFor="yellow_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="green_color" />
                      <label className="green_color" htmlFor="green_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="skyblue_color" />
                      <label className="skyblue_color" htmlFor="skyblue_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="blue_color" />
                      <label className="blue_color" htmlFor="blue_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="grey_color" />
                      <label className="grey_color" htmlFor="grey_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="purple_color" />
                      <label className="purple_color" htmlFor="purple_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="white_color" />
                      <label className="white_color" htmlFor="white_color">
                        &nbsp;
                      </label>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="black_color" />
                      <label className="black_color" htmlFor="black_color">
                        &nbsp;
                      </label>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Type</h4>

                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="1seater_sofas" />
                      <label htmlFor="1seater_sofas">1 Seater Sofas</label>
                      <span>84</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="2seater_sofas" />
                      <label htmlFor="2seater_sofas">2 Seater Sofas</label>
                      <span>259</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="3seater_sofas" />
                      <label htmlFor="3seater_sofas">3 Seater Sofas</label>
                      <span>8</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="sofa_sets" />
                      <label htmlFor="sofa_sets">Sofa Sets</label>
                      <span>45</span>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Style</h4>

                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="scandinavian" />
                      <label htmlFor="scandinavian">Scandinavian</label>
                      <span>84</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="retro" />
                      <label htmlFor="retro">Retro</label>
                      <span>259</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="vintage" />
                      <label htmlFor="vintage">Vintage</label>
                      <span>8</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="provençal" />
                      <label htmlFor="provençal">Provençal</label>
                      <span>45</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="rural" />
                      <label htmlFor="rural">Rural</label>
                      <span>36</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="minimalistic" />
                      <label htmlFor="minimalistic">Minimalistic</label>
                      <span>56</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="industrial" />
                      <label htmlFor="industrial">Industrial</label>
                      <span>5</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="modern" />
                      <label htmlFor="modern">Modern</label>
                      <span>5</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="rustic" />
                      <label htmlFor="rustic">Rustic</label>
                      <span>5</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="oriental" />
                      <label htmlFor="oriental">Oriental</label>
                      <span>5</span>
                    </div>
                  </form>
                </div>
              </div>

              <div className="category_item_list">
                <h4>Size</h4>

                <div className="checkbox_section">
                  <form>
                    <div className="form-group">
                      <input type="checkbox" id="multi_place" />
                      <label htmlFor="multi_place">multi-place</label>
                      <span>84</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="two_digit" />
                      <label htmlFor="two_digit">two-digit</label>
                      <span>259</span>
                    </div>
                    <div className="form-group">
                      <input type="checkbox" id="three_digit" />
                      <label htmlFor="three_digit">three-digit</label>
                      <span>8</span>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-9">
            <div className="breadcrumbs_section">
              <ul>
                <li>
                  <a href="#">
                    Todio.it{" "}
                    <i className="fa fa-angle-right" aria-hidden="true"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    Furniture{" "}
                    <i className="fa fa-angle-right" aria-hidden="true"></i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    Sofa{" "}
                    <i className="fa fa-angle-right" aria-hidden="true"></i>
                  </a>
                </li>
                <li>
                  Green Chair Modular Sofa Bed Ottoman Light Gray Storage Click
                  Clack Pull
                </li>
              </ul>
            </div>

            <section className="buying_product">
              <div className="row">
                <div className="col-lg-6">
                  <div className="img_producto_container" data-scale="1.6">
                    <img
                      className="dslc-lightbox-image img_producto"
                      src={shoplist04}
                      alt="shoplist"
                    />
                  </div>
                  <div className="product_list">
                    <Slider
                      asNavFor={nav2}
                      ref={(slider1) => setNav1(slider1)}
                      {...product_list_slider}
                    >
                      <img src={shoplist04} alt="shoplist" />
                      <img src={shoplist} alt="shoplist" />
                      <img src={shoplist02} alt="shoplist" />
                      <img src={shoplist03} alt="shoplist" />
                      <img src={shoplist04} alt="shoplist" />
                      <img src={shoplist} alt="shoplist" />
                      <img src={shoplist02} alt="shoplist" />
                      <img src={shoplist03} alt="shoplist" />
                    </Slider>
                    <button className="like_count">
                      <svg
                        width="18"
                        height="15"
                        viewBox="0 0 18 15"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M13.0643 0C11.0319 0 9.92864 0.744722 8.99999 1.70194C8.07083 0.744324 6.9676 0 4.93569 0C2.0325 0 0 1.86178 0 4.57437C0 6.17021 0.812965 7.81916 2.32269 9.20217L8.18703 14.6807C8.41944 14.8936 8.70971 15 9 15C9.29028 15 9.58056 14.8936 9.81297 14.6807L15.6773 9.20217C17.187 7.81916 18 6.22331 18 4.57437C18 1.91488 15.9676 0 13.0643 0ZM14.0518 7.71263L8.99992 12.3934L3.94806 7.65921C2.90269 6.70159 2.32215 5.58491 2.32215 4.57426C2.32215 3.03184 3.30918 2.12761 4.93515 2.12761C6.38657 2.12761 6.85136 2.60642 7.95462 3.77656L8.18703 3.98946C8.65138 4.46826 9.52264 4.46826 9.92911 3.98946L10.1615 3.77656C11.2648 2.60649 11.6713 2.12761 13.181 2.12761C14.8069 2.12761 15.794 3.03179 15.794 4.57426C15.6773 5.63833 15.0966 6.70198 14.0518 7.71263Z"
                          fill="#DA4024"
                        />
                      </svg>
                      <span>13</span>
                    </button>
                    <button className="search_add">
                      <img src={search_add} alt="search add" />
                    </button>
                  </div>
                </div>
                <div className="col-lg-6">
                  <div className="product_Details">
                    <h1>
                      green chair Modular Sofa Bed Ottoman Light Gray Storage
                    </h1>
                    <div className="price">
                      <h5>$ 50.00</h5>
                      <h6>$ 160.00</h6>
                    </div>
                    <div className="product_available_delivery">
                      <span className="available">
                        <img src={Available} alt="Available" />
                        <span>Available</span>
                      </span>
                      <span className="delivery">
                        <img src={delivery} alt="delivery" />
                        <span>Free delivery</span>
                      </span>
                    </div>
                    <button>
                      Go To Shop <BiChevronRight />
                    </button>
                  </div>
                </div>
              </div>
            </section>

            <section className="shoplist_slider">
              <Slider
                asNavFor={nav1}
                ref={(slider2) => setNav2(slider2)}
                {...settingsSmallSlider}
              >
                <div className="shoplist_box_cont">
                  <img src={shoplist04} alt="shoplist" />
                </div>
                <div className="shoplist_box_cont">
                  <img src={shoplist01} alt="shoplist" />
                </div>
                <div className="shoplist_box_cont">
                  <img src={shoplist02} alt="shoplist" />
                </div>
                <div className="shoplist_box_cont">
                  <img src={shoplist03} alt="shoplist" />
                </div>
                <div className="shoplist_box_cont">
                  <img src={shoplist04} alt="shoplist" />
                </div>
                <div className="shoplist_box_cont">
                  <img src={shoplist01} alt="shoplist" />
                </div>
                <div className="shoplist_box_cont">
                  <img src={shoplist02} alt="shoplist" />
                </div>
                <div className="shoplist_box_cont">
                  <img src={shoplist03} alt="shoplist" />
                </div>
              </Slider>
            </section>

            <section className="product_desc_spec">
              <Tabs>
                <TabList className="product_data">
                  <Tab className="description">Description</Tab>
                  <Tab className="specifications">Specifications</Tab>
                </TabList>
                <TabPanel className="paragraph">
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book. It has survived not only five centuries,
                    but also the leap into electronic typesetting, remaining
                    essentially unchanged. It was popularised in the 1960s with
                    the release of Letraset sheets containing Lorem Ipsum
                    passages, and more recently with desktop publishing software
                    like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>{" "}
                  <p>
                    Contrary to popular belief, Lorem Ipsum is not simply random
                    text. It has roots in a piece of classical Latin literature
                    from 45 BC, making it over 2000 years old. Richard
                    McClintock, a Latin professor at Hampden-Sydney College in
                    Virginia, looked up one of the more obscure Latin words,
                    consectetur, from a Lorem Ipsum passage, and going through
                    the cites of the word in classical literature, discovered
                    the undoubtable source. Lorem Ipsum comes from sections
                    1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The
                    Extremes of Good and Evil) by Cicero, written in 45 BC. This
                    book is a treatise on the theory of ethics, very popular
                    during the Renaissance. The first line of Lorem Ipsum,
                    "Lorem ipsum dolor sit amet..", comes from a line in section
                    1.10.32.
                  </p>
                </TabPanel>
                <TabPanel className="paragraph">
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen book. It has survived not only five centuries,
                    but also the leap into electronic typesetting, remaining
                    essentially unchanged. It was popularised in the 1960s with
                    the release of Letraset sheets containing Lorem Ipsum
                    passages, and more recently with desktop publishing software
                    like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>{" "}
                </TabPanel>
              </Tabs>
            </section>

            <section className="heading_realted_products">
              <div className="heading">
                <h4>
                  Related <span>Products</span>
                </h4>
              </div>

              <div className="category_product_list_wrap">
                <div>
                  <div className="category_product_list_area">
                    <div className="row">
                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item01} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item02} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item03} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item04} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item05} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item06} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item07} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="category_product_list_box">
                          <div className="discount_wish_area">
                            <div className="category_product_discount">
                              <p>-25%</p>
                            </div>
                            <div className="category_product_wish">
                              <a href="#">
                                <i
                                  className="fa fa-heart-o"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <p>4</p>
                            </div>
                          </div>
                          <div className="category_product_list_box_img">
                            <img src={cat_product_item01} />
                          </div>
                          <div className="category_product_list_box_cont">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                          </div>

                          <div className="category_product_list_box_cont_full">
                            <ul>
                              <li>
                                <img src={available_icon} /> Available
                              </li>
                              <li>
                                <img src={free_icon} /> Free
                              </li>
                            </ul>
                            <h3>
                              Sofa In Orange Colour asd dssdfsdfsdfsd sd as
                            </h3>
                            <div className="category_cont">
                              <p>
                                Upholstered in a soft and hard hello how wearing
                                jumbo cord fabric ..
                              </p>
                            </div>
                            <div className="cat_product_price">
                              <p>
                                $ 39.99 <span>$ 59.99</span>
                              </p>
                            </div>
                            <div className="cat_buttons">
                              <a className="go_details" href="#">
                                Details
                              </a>
                              <a className="go_shop" href="#">
                                Go to shop{" "}
                                <i
                                  className="fa fa-angle-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>

        <section className="similar_categories_product">
          <div className="heading">
            <h4>
              Similar <span>Categories</span>
            </h4>
          </div>
          <Slider {...SimilarCategoriesSlider}>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories01} alt="Similar_Categories01" />
              <h6>Living Room</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories02} alt="Similar_Categories02" />
              <h6>kitchen</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories03} alt="Similar_Categories03" />
              <h6>Out Door</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories04} alt="Similar_Categories04" />
              <h6>Hall</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories05} alt="Similar_Categories05" />
              <h6>Living Room</h6>
              <h4>BOLT - 2 seater sofa</h4>
            </div>

            <div className="similar_categories_product_box">
              <img src={Similar_Categories01} alt="Similar_Categories01" />
              <h6>Living Room</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories02} alt="Similar_Categories02" />
              <h6>kitchen</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories03} alt="Similar_Categories03" />
              <h6>Out Door</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories04} alt="Similar_Categories04" />
              <h6>Hall</h6>
              <h4>Jean Lion king black</h4>
            </div>
            <div className="similar_categories_product_box">
              <img src={Similar_Categories05} alt="Similar_Categories05" />
              <h6>Living Room</h6>
              <h4>BOLT - 2 seater sofa</h4>
            </div>
          </Slider>
        </section>

        <div className="view_category_section">
          <div className="container">
            <div className="title_section_with_view_all">
              <h2>
                <span>View Our</span> Categories
              </h2>
              <div className="view_all">
                <Link>
                  <span>View</span> All +
                </Link>
              </div>
            </div>

            <div className="view_category_list_item">
              <div className="row">
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={fashionIcon} />
                      <h3>Fashion</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={furnitureIcon} />
                      <h3>Furniture</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={shoesIcon} />
                      <h3>Shoes</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={sportsIcon} />
                      <h3>Sports</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={gameingIcon} />
                      <h3>Gameing</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={computersIcon} />
                      <h3>Computers</h3>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

export default Product;
