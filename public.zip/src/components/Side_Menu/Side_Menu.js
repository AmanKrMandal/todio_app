import { React, useState } from "react";
import available_icon from "../../images/available_icon.png";
import free_icon from "../../images/free_icon.png";
import Slider from "@mui/material/Slider";

const Side_Menu = () => {
  const [range, setRange] = useState([0, 100]);
  function handleChanges(event, newValue) {
    setRange(newValue);
  }
  return (
    <div>
      <div className="category_left_section">
        <div className="remove_filters_section">
          <h3>Remove filters</h3>
          <ul>
            <li>
              <div className="remove_filters_box">
                <p>without shade</p>
                <span>
                  <a href="#">
                    <i className="fa fa-times" aria-hidden="true"></i>
                  </a>
                </span>
              </div>
            </li>
            <li>
              <div className="remove_filters_box">
                <p>modern</p>
                <span>
                  <a href="#">
                    <i className="fa fa-times" aria-hidden="true"></i>
                  </a>
                </span>
              </div>
            </li>
            <li>
              <a href="#">Remove everything</a>
            </li>
          </ul>
        </div>

        <div className="Search_in_the_category_section">
          <h3>Search in the category</h3>
          <form>
            <input type="text" />
            <input type="submit" />
          </form>
        </div>

        <div className="category_item_list">
          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="multi_place" />
                <label className="check_available" for="multi_place">
                  <img src={available_icon} /> Available
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="two_digit" />
                <label for="two_digit">
                  <img src={free_icon} /> Free
                </label>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Price</h4>

          <div className="price_range_section">
            <div className="price_range_section_box">
              <div>$ {range[0]}</div>
              <div>$ {range[1]}</div>
            </div>
            <Slider
              value={range}
              onChange={handleChanges}
              valueLabelDisplay="auto"
            />
          </div>

          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="cheap" />
                <label for="cheap">Cheap</label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="luxurious" />
                <label for="luxurious">Luxurious</label>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Categories</h4>

          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="furniture" />
                <label for="furniture">Furniture</label>
                <span>84</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="decoraton" />
                <label for="decoraton">Decoraton</label>
                <span>259</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="iextile" />
                <label for="iextile">Textile</label>
                <span>8</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="lamps" />
                <label for="lamps">Lamps</label>
                <span>45</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="construction" />
                <label for="construction">Construction</label>
                <span>36</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="accessories" />
                <label for="accessories">Accessories</label>
                <span>56</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="others" />
                <label for="others">Others</label>
                <span>5</span>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Subcategories</h4>

          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="sofas" />
                <label for="sofas">Sofas</label>
                <span>84</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="sofa" />
                <label for="sofa">Sofa</label>
                <span>259</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="armchairs_seats" />
                <label for="armchairs_seats">Armchairs and Seats</label>
                <span>8</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="beds" />
                <label for="beds">Beds</label>
                <span>45</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="cabinets_lockers" />
                <label for="cabinets_lockers">Cabinets and lockers</label>
                <span>36</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="fitted_kitchens" />
                <label for="fitted_kitchens">Fitted kitchens</label>
                <span>56</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="coffee_tables" />
                <label for="coffee_tables">Tables and Coffee tables</label>
                <span>5</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="sittings" />
                <label for="sittings">Sittings</label>
                <span>5</span>
              </div>

              <div className="form-group">
                <input type="checkbox" id="furniture_set" />
                <label for="furniture_set">Furniture set</label>
                <span>5</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="storage_spaces" />
                <label for="storage_spaces">Storage spaces</label>
                <span>5</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="office_furnishings" />
                <label for="office_furnishings">Office furnishings</label>
                <span>5</span>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Brand</h4>

          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="febonic" />
                <label for="febonic">Febonic</label>
                <span>84</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="durian" />
                <label for="durian">Durian</label>
                <span>259</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="dreamzz_furniture" />
                <label for="dreamzz_furniture">Dreamzz Furniture</label>
                <span>8</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="adorn_homez" />
                <label for="adorn_homez">Adorn Homez</label>
                <span>45</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="furnitech" />
                <label for="furnitech">Furnitech</label>
                <span>36</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="wakefit" />
                <label for="wakefit">Wakefit</label>
                <span>56</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="others" />
                <label for="others">Others</label>
                <span>5</span>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Color</h4>

          <div className="checkbox_section for_color">
            <form>
              <div className="form-group">
                <input type="checkbox" id="red_color" />
                <label className="red_color" for="red_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="yellow_color" />
                <label className="yellow_color" for="yellow_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="green_color" />
                <label className="green_color" for="green_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="skyblue_color" />
                <label className="skyblue_color" for="skyblue_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="blue_color" />
                <label className="blue_color" for="blue_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="grey_color" />
                <label className="grey_color" for="grey_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="purple_color" />
                <label className="purple_color" for="purple_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="white_color" />
                <label className="white_color" for="white_color">
                  &nbsp;
                </label>
              </div>
              <div className="form-group">
                <input type="checkbox" id="black_color" />
                <label className="black_color" for="black_color">
                  &nbsp;
                </label>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Type</h4>

          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="1seater_sofas" />
                <label for="1seater_sofas">1 Seater Sofas</label>
                <span>84</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="2seater_sofas" />
                <label for="2seater_sofas">2 Seater Sofas</label>
                <span>259</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="3seater_sofas" />
                <label for="3seater_sofas">3 Seater Sofas</label>
                <span>8</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="sofa_sets" />
                <label for="sofa_sets">Sofa Sets</label>
                <span>45</span>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Style</h4>

          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="scandinavian" />
                <label for="scandinavian">Scandinavian</label>
                <span>84</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="retro" />
                <label for="retro">Retro</label>
                <span>259</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="vintage" />
                <label for="vintage">Vintage</label>
                <span>8</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="provençal" />
                <label for="provençal">Provençal</label>
                <span>45</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="rural" />
                <label for="rural">Rural</label>
                <span>36</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="minimalistic" />
                <label for="minimalistic">Minimalistic</label>
                <span>56</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="industrial" />
                <label for="industrial">Industrial</label>
                <span>5</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="modern" />
                <label for="modern">Modern</label>
                <span>5</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="rustic" />
                <label for="rustic">Rustic</label>
                <span>5</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="oriental" />
                <label for="oriental">Oriental</label>
                <span>5</span>
              </div>
            </form>
          </div>
        </div>

        <div className="category_item_list">
          <h4>Size</h4>

          <div className="checkbox_section">
            <form>
              <div className="form-group">
                <input type="checkbox" id="multi_place" />
                <label for="multi_place">multi-place</label>
                <span>84</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="two_digit" />
                <label for="two_digit">two-digit</label>
                <span>259</span>
              </div>
              <div className="form-group">
                <input type="checkbox" id="three_digit" />
                <label for="three_digit">three-digit</label>
                <span>8</span>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Side_Menu;
