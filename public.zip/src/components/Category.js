import React, { useRef, useEffect, useState } from "react";

import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";

import $ from "jquery";
import { Link } from "react-router-dom";


import category01 from "../images/category01.png";
import category02 from "../images/category02.png";
import category03 from "../images/category03.png";
import category04 from "../images/category04.png";
import category05 from "../images/category05.png";
import category06 from "../images/category06.png";
import category07 from "../images/category07.png";
import category08 from "../images/category08.png";
import category09 from "../images/category09.png";
import category10 from "../images/category10.png";
import category11 from "../images/category11.png";
import category12 from "../images/category12.png";
import category13 from "../images/category13.png";
import category14 from "../images/category14.png";
import category15 from "../images/category15.png";
import category16 from "../images/category16.png";
import category17 from "../images/category17.png";



import fashionIcon from "../images/fashion_icon.png";
import furnitureIcon from "../images/furniture_icon.png";
import shoesIcon from "../images/shoes_icon.png";
import sportsIcon from "../images/sports_icon.png";
import gameingIcon from "../images/gameing_icon.png";
import computersIcon from "../images/computers_icon.png";

import "../css/category.css";
import Side_Menu from "./Side_Menu/Side_Menu";
import Related_Products from "./Related_Products/Related_Products";

const Category = () => {
 

  return (
    <div className="category_container">
      <div className="container">
        <div className="category_wrapper">
          <div className="row">
            <div className="col-md-3">
              <Side_Menu />
            </div>
            <div className="col-md-9">
              <div className="category_right_section">
                <div className="breadcrumbs_section">
                  <ul>
                    <li>
                      <a href="#">
                        Todio.it{" "}
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li>Furniture</li>
                  </ul>
                </div>

                <h1>Furniture</h1>

                <div className="category_content_info">
                  <div id="section">
                    <div className="article">
                      <p>
                        A couch, also known as a sofa, settee, or chesterfield,
                        is a cushioned item of furniture for seating multiple
                        people (although it is not uncommon for a single person
                        to use a couch alone). A couch, also known as a sofa,
                        settee, or chesterfield.
                      </p>
                      <p className="moretext">
                        A couch, also known as a sofa, settee, or chesterfield,
                        is a cushioned item of furniture
                      </p>
                    </div>
                    <a className="moreless-button" href="#">
                      Read more...
                    </a>
                  </div>
                </div>

                <div className="product_category_section">
                  <div className="row">
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category01} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Sofas</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category02} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Sofa</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category03} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Armchairs and seats</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category04} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Beds</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>

                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category05} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Cabinets and lockers</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category06} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Fitted kitchens</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category07} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Tables and coffee tables</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category08} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Sittings</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>

                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category09} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Furniture set</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category10} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Storage spaces</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category11} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Office furnishings</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category12} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Outdoor furniture</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>

                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category13} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Coat hanger, glove box and hooks</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category14} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Entrance furniture</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category15} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Children's furniture</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category16} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Bathroom furniture</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>

                    <div className="col-md-3">
                      <div className="product_category_box">
                        <a href="#">
                          <div className="product_category_box_area">
                            <div className="product_category_box_img">
                              <img src={category17} />
                            </div>
                            <div className="product_category_box_cont">
                              <h3>Balcony furniture</h3>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="category_product_list_section">
                  <div className="total_number_of_product">
                    <p>(78 products)</p>
                  </div>
                  <Tabs>
                    <div className="tab_box">
                      <TabList>
                        <Tab>Recommended</Tab>
                        <Tab>Favorites</Tab>
                        <Tab>Latest</Tab>
                        <Tab>More convenient</Tab>
                        <Tab>More expensive</Tab>
                      </TabList>
                    </div>

                    <Related_Products/>
                  </Tabs>
                </div>

                <div className="loadmore_paging_section">
                  <div className="load_more_product">
                    <a href="#">Load more products</a>
                  </div>
                  <div className="paging_area">
                    <ul>
                      <li className="active">
                        <a href="#">1</a>
                      </li>
                      <li>
                        <a href="#">2</a>
                      </li>
                      <li>
                        <a href="#">3</a>
                      </li>
                      <li>
                        <a href="#">4</a>
                      </li>
                      <li>
                        <a href="#">5</a>
                      </li>
                      <li>
                        <a href="#">Next</a>
                      </li>
                      <li>
                        <a className="last" href="#">
                          Last
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="view_category_section">
          <div className="container">
            <div className="title_section_with_view_all">
              <h2>
                <span>View Our</span> Categories
              </h2>
              <div className="view_all">
                <Link>
                  <span>View</span> All +
                </Link>
              </div>
            </div>

            <div className="view_category_list_item">
              <div className="row">
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={fashionIcon} />
                      <h3>Fashion</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={furnitureIcon} />
                      <h3>Furniture</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={shoesIcon} />
                      <h3>Shoes</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={sportsIcon} />
                      <h3>Sports</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={gameingIcon} />
                      <h3>Gameing</h3>
                    </Link>
                  </div>
                </div>
                <div className="col-md-2 view_category_list_item_box_area">
                  <div className="view_category_list_item_box">
                    <Link>
                      <img src={computersIcon} />
                      <h3>Computers</h3>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

$(document).ready(function () {
  //

  //

  // Content show more less start

  $(".moreless-button").click(function () {
    $(".moretext").slideToggle();
    if ($(".moreless-button").text() == "Read more...") {
      $(this).text("Read less...");
    } else {
      $(this).text("Read more...");
    }
  });

  // Content show more less ends

  // Mobile Menu start

  function sidemenu() {
    $(".nav_sec").toggleClass("slidein");
    $(".nav_sec").prepend('<div class="cls-btn"></div>');

    $(".cls-btn").on("click", function () {
      $(".nav_sec").removeClass("slidein");
    });
  }

  $(".toggle-menu").click(sidemenu);
  $(".nav_sec ul > li > ul").parent().prepend('<i class="arw-nav"></i>');

  function subMenu() {
    $(this).parent("li").find("> ul").stop(true, true).slideToggle();
    $(this).parents("li").siblings().find("ul").stop(true, true).slideUp();
    $(this).toggleClass("actv");
    $(this).parent().siblings().find(".arw-nav").removeClass("actv");
  }
  $(".nav_sec ul > li > .arw-nav").on("click", subMenu);

  // Mobile Menu ends
});

export default Category;
