jQuery(function ($) {
  /* ========== Fixed Header ========== */
  $(window)
    .scroll(function () {
      //var scroll = $(window).scrollTop();
      if ($(window).scrollTop() >= 1) {
        $(".header_bottom").addClass("fixed");
      } else {
        $(".header_bottom").removeClass("fixed");
      }
    })
    .scroll();
  /* ========== End Fixed Header ========== */

  // Mobile Menu start

  function sidemenu() {
    $(".nav_sec").toggleClass("slidein");
    $(".nav_sec").prepend('<div class="cls-btn"></div>');

    $(".cls-btn").on("click", function () {
      $(".nav_sec").removeClass("slidein");
    });
  }

  $(".toggle-menu").click(sidemenu);
  $(".nav_sec ul > li > ul").parent().prepend('<i class="arw-nav"></i>');

  function subMenu() {
    $(this).parent("li").find("> ul").stop(true, true).slideToggle();
    $(this).parents("li").siblings().find("ul").stop(true, true).slideUp();
    $(this).toggleClass("actv");
    $(this).parent().siblings().find(".arw-nav").removeClass("actv");
  }
  $(".nav_sec ul > li > .arw-nav").on("click", subMenu);

  // Mobile Menu ends
});
